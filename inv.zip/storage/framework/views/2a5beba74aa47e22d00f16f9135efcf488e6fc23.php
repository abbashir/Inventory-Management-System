<?php $__env->startSection('title','Category'); ?>

<?php $__env->startSection('body_content'); ?>

<?php $m = Session::get('message') ?>
<?php if(@isset ($m)): ?>
<div class="alert alert-success no-border mb-2" role="alert">
    <strong>Well done!</strong> <?php echo e($m); ?>

  </div>
<?php endif; ?>

<!-- product table -->
<div class="card col-xs-12">
            <div class="card-header">
                <h4 class="card-title">Product table</h4>
                <a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
                <div class="heading-elements">
                    <ul class="list-inline mb-0">
                        <li><a data-action="collapse"><i class="icon-minus4"></i></a></li>
                        <li><a data-action="reload"><i class="icon-reload"></i></a></li>
                        <li><a data-action="expand"><i class="icon-expand2"></i></a></li>
                       
                    </ul>
                </div>
            </div>

  <div class="card-body collapse in">
      
      <div class="table-responsive">
          <table class="table table-bordered mb-0">
              <thead class="thead-inverse">
                    <tr>
                        <th>Name</th>
                        <th>Category</th>
                        <th>Brand</th>
                        <th>price</th>
                        <th>Title</th>
                        <th>Description</th>
                        <th >Status</th>
                        <th style="width: 160px;">Action</th>

             
                  </tr>
             </thead>

              <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="small">

                    <td><?php echo e($product->productName); ?></td>
                    <td><?php echo e($product->productCategory); ?></td>
                    <td><?php echo e($product->productBrand); ?></td>
                    <td><?php echo e($product->productPrice); ?></td>
                    <td><?php echo e($product->productTitle); ?></td>
                    <td><?php echo e($product->productDescription); ?></td>
                  <td><?php echo e($product->PublicationStatus == 1 ? 'Active' : 'Inactive'); ?></td>

                  <td>
                      <a href="<?php echo e(url('/product/update/'.$product->id)); ?>" class="btn btn-success" style="margin-right: 10px;">
                       <i class="icon-edit2"></i>
                     </a>

                     <a href="<?php echo e(url('/product/delete/'.$product->id)); ?>" class="btn btn-danger" onclick="return confirm('Are you sure delete this product ?')">
                      <i class="icon-trash-o"></i>
                    </a>

                  </td>

          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
            </tbody>
                    </table>
                </div>
            </div>
        </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>