<?php $__env->startSection('title','New Invoice'); ?>


<?php $__env->startSection('body_content'); ?>

<?php $m = Session::get('message') ?>
<?php if(@isset ($m)): ?>
<div class="alert alert-success no-border mb-2" role="alert">
    <strong>Well done!</strong> <?php echo e($m); ?>

  </div>
<?php endif; ?>
<!-- form start -->
<div class="col-md-12">
	<div class="card">
		<div class="card-header">
			<h4 class="card-title" id="basic-layout-form-center">New Invoice</h4>
			<a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
			<div class="heading-elements">
				<ul class="list-inline mb-0">
					<li><a data-action="collapse"><i class="icon-minus4"></i></a></li>
					<li><a data-action="reload"><i class="icon-reload"></i></a></li>
					<li><a data-action="expand"><i class="icon-expand2"></i></a></li>
					
				</ul>
			</div>
		</div>
		<div class="card-body collapse in">
			<div class="card-block">

				<?php echo Form::open(['url' => '/saveCustomer','name'=>'addproductForm']); ?> <!-- use collective laravel pac-->

				<div class="row">
					<div class="col-md-6 offset-md-3">
						<div class="form-body">

							

							



								








								

							
							

						</div>
					</div>
				</div>

				<div class="form-actions center">
					<button type="button" class="btn btn-warning mr-1">
						<i class="icon-cross2"></i> Cancel
					</button>
					<button type="submit" class="btn btn-primary">
						<i class="icon-check2"></i> Save
					</button>
				</div>
				<?php echo Form::close(); ?>


			</div>
		</div>
	</div>
</div>
<!-- form end -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>