<?php $__env->startSection('title','Bank transaction'); ?>


<?php $__env->startSection('body_content'); ?>

<?php $m = Session::get('message') ?>
<?php if(@isset ($m)): ?>
<div class="alert alert-success no-border mb-2" role="alert">
    <strong>Well done!</strong> <?php echo e($m); ?>

  </div>
<?php endif; ?>

<!-- form start -->
<div class="col-md-12">
  <div class="card">
    <div class="card-header">
      <h4 class="card-title" id="basic-layout-form-center">Bank transaction</h4>
      <a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
      <div class="heading-elements">
        <ul class="list-inline mb-0">
          <li><a data-action="collapse"><i class="icon-minus4"></i></a></li>
          <li><a data-action="reload"><i class="icon-reload"></i></a></li>
          <li><a data-action="expand"><i class="icon-expand2"></i></a></li>
          
        </ul>
      </div>
    </div>
    <div class="card-body collapse in">
      <div class="card-block">
      <form class="form-horizontal">
<fieldset>

<!-- Form Name -->
<legend>Form Name</legend>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-2 control-label" for="textinput">Email : </label>  
  <div class="col-md-10">
  <input id="textinput" name="textinput" type="text" placeholder="enter your email" class="form-control input-md" required="">
    
  </div>
</div><br><br>

<div class="form-group">
  <label class="col-md-2 control-label" for="textinput">Email</label>  
  <div class="col-md-10">
  <input id="textinput" name="textinput" type="text" placeholder="enter your email" class="form-control input-md" required="">
    
  </div>
</div>
<div class="form-group">
  <label class="col-md-2 control-label" for="textinput">Email</label>  
  <div class="col-md-10">
  <input id="textinput" name="textinput" type="text" placeholder="enter your email" class="form-control input-md" required="">
    
  </div>
</div>





</fieldset>
</form>

        

      </div>
    </div>
  </div>
</div>
<!-- form end -->






<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>