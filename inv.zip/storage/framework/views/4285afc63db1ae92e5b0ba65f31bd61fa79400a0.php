<div data-scroll-to-active="true" class="main-menu menu-fixed menu-dark menu-accordion menu-shadow">
      <!-- main menu header-->
      <div class="main-menu-header">
        <input type="text" placeholder="Search" class="menu-search form-control round"/>
      </div>
      <!-- / main menu header-->
      <!-- main menu content-->
      <div class="main-menu-content">
        <ul id="main-menu-navigation" data-menu="menu-navigation" class="navigation navigation-main">

          <li class=" nav-item"><a href="<?php echo e(url('/dashboard')); ?>"><i class="icon-home3"></i><span data-i18n="nav.dash.main" class="menu-title">Dashboard</span></a>
          </li>

         <!--   <li class=" nav-item"><a href="index.html"><i class="icon-home3"></i><span data-i18n="nav.form_layouts.form_layout_basic" class="menu-title">Basic Forms</span></a>
          </li>
 -->

        

          <li class=" nav-item"><a href="<?php echo e(url('/brands')); ?>"><i class="icon-home3"></i><span data-i18n="nav.form_layouts.form_layout_basic" class="menu-title">Brands</span></a>
        </li>


         <li class=" nav-item"><a href="<?php echo e(url('/category')); ?>"><i class="icon-stack-2"></i><span data-i18n="nav.form_layouts.form_layout_basic" class="menu-title">Categories</span></a>
        </li>



          <li class=" nav-item"><a href="#"><i class="icon-stack-2"></i><span data-i18n="nav.page_layouts.main" class="menu-title">Store</span></a>
            <ul class="menu-content">
              <li><a href="layout-1-column.html" data-i18n="nav.page_layouts.1_column" class="menu-item">Add Store</a>
              </li>

              <li><a href="layout-2-columns.html" data-i18n="nav.page_layouts.2_columns" class="menu-item">Manage Store</a>
              </li>
            </ul>
          </li>


           <li class=" nav-item"><a href="#"><i class="icon-stack-2"></i><span data-i18n="nav.page_layouts.main" class="menu-title">Products</span></a>
            <ul class="menu-content">
              <li><a href="<?php echo e(url('/product/add-product')); ?>" data-i18n="nav.page_layouts.1_column" class="menu-item">Add Product</a>
              </li>

              <li><a href="<?php echo e(url('/product/manage-product')); ?>" data-i18n="nav.page_layouts.2_columns" class="menu-item">Manage Product</a>
              </li>
            </ul>
          </li>


            <li class=" nav-item"><a href="#"><i class="icon-stack-2"></i><span data-i18n="nav.page_layouts.main" class="menu-title">Orders</span></a>
            <ul class="menu-content">
              <li><a href="layout-1-column.html" data-i18n="nav.page_layouts.1_column" class="menu-item">Add Order</a>
              </li>

              <li><a href="layout-2-columns.html" data-i18n="nav.page_layouts.2_columns" class="menu-item">Manage Order</a>
              </li>
            </ul>
          </li>


        <li class=" nav-item"><a href="index.html"><i class="icon-home3"></i><span data-i18n="nav.form_layouts.form_layout_basic" class="menu-title">Reports</span></a>
        </li>


         <li class=" nav-item"><a href="#"><i class="icon-stack-2"></i><span data-i18n="nav.page_layouts.main" class="menu-title">Company</span></a>
            <ul class="menu-content">
              <li><a href="layout-1-column.html" data-i18n="nav.page_layouts.1_column" class="menu-item">Add Company</a>
              </li>

              <li><a href="layout-2-columns.html" data-i18n="nav.page_layouts.2_columns" class="menu-item">Manage Company</a>
              </li>
            </ul>
          </li>


            <li class=" nav-item"><a href="index.html"><i class="icon-home3"></i><span data-i18n="nav.form_layouts.form_layout_basic" class="menu-title">Customer List</span></a>
        </li>


            <li class=" nav-item"><a href="#"><i class="icon-stack-2"></i><span data-i18n="nav.page_layouts.main" class="menu-title">Users</span></a>
            <ul class="menu-content">
              <li><a href="layout-1-column.html" data-i18n="nav.page_layouts.1_column" class="menu-item">Add user</a>
              </li>

              <li><a href="layout-2-columns.html" data-i18n="nav.page_layouts.2_columns" class="menu-item">Manage user</a>
              </li>
            </ul>
          </li>


        
        </ul>
      </div>
      <!-- /main menu content-->
      <!-- main menu footer-->
      <!-- include includes/menu-footer-->
      <!-- main menu footer-->
    </div>