<?php $__env->startSection('title','Add Product'); ?>

<?php $__env->startSection('body_content'); ?>


<!-- form start -->
<div class="col-md-12">
	<div class="card">
		<div class="card-header">
			<h4 class="card-title" id="basic-layout-form-center">Update Product form</h4>
			<a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
			<div class="heading-elements">
				<ul class="list-inline mb-0">
					<li><a data-action="collapse"><i class="icon-minus4"></i></a></li>
					<li><a data-action="reload"><i class="icon-reload"></i></a></li>
					<li><a data-action="expand"><i class="icon-expand2"></i></a></li>
					
				</ul>
			</div>
		</div>
		<div class="card-body collapse in">
			<div class="card-block">

				<?php echo Form::open(['url' => '/saveProduct','name'=>'addproductForm']); ?> <!-- use collective laravel pac-->

				<div class="row">
					<div class="col-md-6 offset-md-3">
						<div class="form-body">

							<div class="form-group">
								<?php echo e(Form::label('text', 'Product Name:')); ?>

								
								<input type="text" name="productName" class="form-control" placeholder="Enter product name" required="required" value="">

							</div>


							<div class="form-group">
									<label for="issueinput5">Product Category</label>
									<select id="issueinput5" name="productCategory" class="form-control" data-toggle="tooltip" data-trigger="hover" data-placement="top" data-title="Priority" data-original-title="" title="">
										<option value="low">Pick a Category</option>
									
									</select>
								</div>


								<div class="form-group">
									<label for="issueinput5">Product Brand</label>
									<select id="issueinput5" name="productBrand" class="form-control" data-toggle="tooltip" data-trigger="hover" data-placement="top" data-title="Priority" data-original-title="" title="">
										<option value="low">Pick a Brand</option>
										
										

									</select>
								</div>


								<div class="form-group">
									<label>Product Price</label>
									<div class="input-group">
										<span class="input-group-addon">$</span>
										<input type="text" class="form-control square" placeholder="Enter Price" aria-label="Amount (to the nearest dollar)" name="productPrice">
										<span class="input-group-addon">.00</span>
									</div>
								</div>


								<div class="form-group">
									<label for="complaintinput2">Product Title</label>
									<input type="text" id="complaintinput2" class="form-control round" placeholder="Enter Title" name="productTitle">
								</div>


								<div class="form-group">
									<label for="donationinput7">Description</label>
									<textarea id="donationinput7" rows="5" class="form-control square" name="productDesc" placeholder="Enter product Description"></textarea>
								</div>


								<!-- <div class="form-group">
									<label>Product Image</label>
									<label id="projectinput7" class="file center-block">
										<input type="file" id="file" name="productImage">
										<span class="file-custom"></span>
									</label>
								</div>
 -->

								<div class="form-group">
								<?php echo e(Form::label('text', 'Publication Status:')); ?>

								

								<?php echo e(Form::select('productStatus', ['1' => 'Published', '0' => 'Unpublished'], null, ['placeholder' => 'Pick a Status','class'=>'form-control','required','autofocus'])); ?>


							</div>

							
							

						</div>
					</div>
				</div>

				<div class="form-actions center">
					<button type="button" class="btn btn-warning mr-1">
						<i class="icon-cross2"></i> Cancel
					</button>
					<button type="submit" class="btn btn-primary">
						<i class="icon-check2"></i> Update
					</button>
				</div>
				<?php echo Form::close(); ?>


			</div>
		</div>
	</div>
</div>
<!-- form end -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>