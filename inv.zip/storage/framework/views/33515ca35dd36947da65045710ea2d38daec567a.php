 <footer class="footer footer-static footer-light navbar-border text-center">
      <p class="text-center">
      	Developed by Abdul Bashir
      </p>
 </footer>